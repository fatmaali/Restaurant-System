<?php
require_once '../Controller/QueryBuilder.php';


$q= new QueryBuilder();
//$q->getPostIDByUserID(1);
//$q->UpdateConfirmation(1);
$q->enrollFace();

?>